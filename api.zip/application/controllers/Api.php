<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

	function __construct()
	{
		$this->data = array();
	}
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function insert_users(){
		$response = array('status'=>true);
		if($this->input->post()){
			$db_array = array();
			$db_array['user_name'] = $this->input->post('user_name');
			$db_array['user_father_name'] = $this->input->post('user_father_name');
			$db_array['user_address'] = $this->input->post('user_address');
			$db_array['user_pan_number'] = $this->input->post('user_pan_number');
			$db_array['user_rate_of_interest'] = $this->input->post('user_rate_of_interest');
			$db_array['user_aadhar'] = $this->input->post('user_aadhar');
			$db_array['user_mobile'] = $this->input->post('user_mobile');
			$db_array['user_status'] = $this->input->post('user_status');
			$db_array['user_type'] = $this->input->post('user_type');
			$db_array['user_note'] = $this->input->post('user_note');

			if($this->db->insert('users_data',$db_array)){
				$response['status'] = true;
			}else{
				$response['msg'] = 'db_error';
			}
		}
		echo json_encode($response);
	}
	public function user_single(){
		$response = array('status'=>true);
		if($this->input->get('user_mobile') && $this->input->get('user_aadhar')){
			$sql = $this->db->query("SELECT * FROM users_data WHERE user_mobile='".$this->input->get('user_mobile')."' AND user_aadhar='".$this->input->get('user_aadhar')."' LIMIT 1 ");
			if($sql->num_rows()>0){
				$response['status'] = true;
				$response['user_details'] = $sql->row_array();
			}else{
				$response['msg'] = 'not_found';
			}
		}
		echo json_encode($response);
	}
}
